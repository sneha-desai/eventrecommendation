$(document).ready(function() {
    $('i').click(function(){
    var id = $(this).attr('id');
    if(id.slice(0,-1) === "like-"){
        $("#" + id).toggleClass("liked");
    }else{
        $("#" + id).toggleClass("disliked");
    }  
    //$("#" + id).toggleClass("liked");
    var lastChar = id[id.length-1];
    if($("#like-" + lastChar).hasClass("liked") && $("#dislike-" + lastChar).hasClass("disliked")){
        if(id.slice(0,-1) === "like-"){
            $("#dislike-" + lastChar).toggleClass("disliked");
        }else{
            $("#like-" + lastChar).toggleClass("liked");
        }    
    }
});

var mydata = JSON.parse(data);
for(var i=0; i < mydata.length; i++ ){
    $("#event-" + i).html(mydata[i].title);
    $("#detail-" + i).html(mydata[i].place + "-" + mydata[i].date + " " + mydata[i].time);
    $("#image-" + i).attr("src", mydata[i].image);
    
}

});



