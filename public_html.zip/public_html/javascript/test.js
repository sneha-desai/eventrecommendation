var mydata = JSON.parse(data);
alert(mydata[0].title);